export class QuestionResultDto {
  label: string; // El texto de la opción (ej: "Hombre", "18-24")
  value: number; // El conteo de respuestas para esa opción
}